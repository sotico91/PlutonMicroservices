﻿namespace MSPerson.Domain
{
	public enum PersonType
    {
        Doctor,
        Patient
    }
}